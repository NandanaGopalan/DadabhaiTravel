﻿using JobApplication.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace JobApplication.Controllers
{
    public class JobController : Controller
    {
        //
        // GET: /Job/

        public async Task<ActionResult> Index()
        {
            //Get the job data
            IEnumerable<JobOutputModel> jobs = await GetJobWebAPIData();
            return View(jobs);
        }

        public async Task<IEnumerable<JobOutputModel>> GetJobWebAPIData()
        {
            IEnumerable<JobOutputModel> jobs = null;

            using (var httpClient = new HttpClient())
            {
                //for TSL security
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            
                //Public API
                httpClient.BaseAddress = new Uri("https://jobs.github.com/positions.json");

                //Get request
                var responseTask =await httpClient.GetAsync("");
                //If data is getting 
                if (responseTask.IsSuccessStatusCode)
                {
                    var readTask = responseTask.Content.ReadAsAsync<IList<JobOutputModel>>();
                    readTask.Wait();

                    jobs = readTask.Result;

                }
                else
                {
                    jobs = Enumerable.Empty<JobOutputModel>();
                    ModelState.AddModelError(string.Empty, "Server Error.");
                }
            }
            return jobs;

        }
    }
}
